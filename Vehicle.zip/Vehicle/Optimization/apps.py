from django.apps import AppConfig


class OptimizationConfig(AppConfig):
    name = 'Optimization'
